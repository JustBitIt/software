#include "JobCopySqlData.h"
#include "PocoCommon.h"

extern "C"
{
#include "lua.h"  
#include "lauxlib.h"  
#include "lualib.h"  
}


JobCopySqlDate::JobCopySqlDate()
{
}

JobCopySqlDate::~JobCopySqlDate()
{
}

int JobCopySqlDate::processJob(std::shared_ptr<sql::Connection> connection)
{
	Application& app = Application::instance();
	//Application::instance().logger().information("busy doing nothing... " + DateTimeFormatter::format(app.uptime()));
	Application::instance().logger().information("JobCopySqlDate: come in dates ...\n");

	int result = 0;

	//1.����һ��state  ;
	lua_State *L = luaL_newstate();
	//2.��ջ����  ;
	lua_pushstring(L, "I am so cool~ \n");
	lua_pushnumber(L, 20);
	//3.ȡֵ����  ;
	if (lua_isstring(L, 1)){             //�ж��Ƿ����תΪstring  ;
		std::cout << lua_tostring(L, 1) << std::endl;  //תΪstring������  ;
	}
	if (lua_isnumber(L, 2)){
		std::cout << lua_tonumber(L, 2) << std::endl;
	}
	//4.�ر�state  ;
	lua_close(L);

	//do
	//{
	//	try {

	//		std::unique_ptr<sql::Statement> stmt(connection->createStatement());


	//		//std::string sql = "SELECT * FROM t_word_list limit 10";
	//		std::unique_ptr<sql::ResultSet> res(stmt->executeQuery("SELECT * FROM t_word_list"));

	//		while (res->next()) {

	//			WordItem item;
	//			item.id = std::to_string(res->getInt("word_id"));
	//			item.key = res->getString("key").c_str();
	//			item.value = res->getString("value").c_str();
	//			item.code = res->getString("code").c_str();
	//			item.type = std::to_string(res->getInt("type"));
	//			item.ip = res->getString("public_ip").c_str();
	//			item.used_count = std::to_string(res->getInt("used_count"));
	//			item.date = res->getString("date").c_str();

	//			m_vecWordList.push_back(item); 

	//			Application::instance().logger().information(item.key.c_str());

	//			//Poco::JSON::Object jsn_one_info;
	//			//jsn_one_info.set("num", num);
	//			//jsn_one_info.set("date", date);
	//			//arrayActiveAll.add(jsn_one_info);

	//		}
	//	}
	//	catch (sql::SQLException& e) {
	//		std::cout << "# ERR: SQLException in " << __FILE__;
	//		std::cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << std::endl;
	//		std::cout << "# ERR: " << e.what();
	//		std::cout << " (MySQL error code: " << e.getErrorCode();
	//		std::cout << ", SQLState: " << e.getSQLState() << " )" << std::endl;
	//		result = -1;
	//		break;
	//	}
	//} while (0);

	return result;
}
