#ifndef ___POCO__COMM_H___
#define ___POCO__COMM_H___
#include "Poco/Util/ServerApplication.h"
#include "Poco/Util/Option.h"
#include "Poco/Util/OptionSet.h"
#include "Poco/Util/HelpFormatter.h"
#include "Poco/Task.h"
#include "Poco/TaskManager.h"
#include "Poco/DateTimeFormatter.h"
#include "Poco/Task.h"
#include "Poco/TaskManager.h"

#include "Poco/Timer.h"
#include "Poco/Thread.h"
#include "Poco/Stopwatch.h"

#include "Poco/ConsoleChannel.h"  
#include "Poco/FileChannel.h"  
#include "Poco/SplitterChannel.h"  
#include "Poco/FormattingChannel.h"  
#include "Poco/PatternFormatter.h"  
#include "Poco/Logger.h"  
#include "Poco/AutoPtr.h"  

using Poco::Logger;
using Poco::ConsoleChannel;
using Poco::FileChannel;
using Poco::SplitterChannel;
using Poco::FormattingChannel;
using Poco::PatternFormatter;
using Poco::AutoPtr;



using Poco::Timer;
using Poco::TimerCallback;
using Poco::Thread;
using Poco::Stopwatch;

using Poco::Util::Application;
using Poco::Util::ServerApplication;
using Poco::Util::Option;
using Poco::Util::OptionSet;
using Poco::Util::OptionCallback;
using Poco::Util::HelpFormatter;
using Poco::Task;
using Poco::TaskManager;
using Poco::DateTimeFormatter;

#endif // !___POCO__COMM_H___
