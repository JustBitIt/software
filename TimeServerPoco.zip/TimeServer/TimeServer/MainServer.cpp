//author:wufeng;
//date:2017-3-15;
#include "PocoCommon.h"
#include "JobTaskManager.h"

class QDRSServer : public ServerApplication
{
public:
	QDRSServer() : _helpRequested(false)
	{
	}

	~QDRSServer()
	{
	}

protected:
	void initialize(Application& self)
	{
		loadConfiguration(); // load default configuration files, if present
		ServerApplication::initialize(self);


		//��׼���;
		AutoPtr<ConsoleChannel> pConsoleChannel(new ConsoleChannel);

		//��־�ļ�����;  
		AutoPtr<FileChannel> pFileChannel(new FileChannel);
		pFileChannel->setProperty("path", "fileLog.log");
		pFileChannel->setProperty("archive", "timestamp");
		pFileChannel->setProperty("times", "local");
		pFileChannel->setProperty("rotation", "1 hours");
		pFileChannel->setProperty("purgeAge", "1 weeks");// 
		pFileChannel->setProperty("compress", "false");
		pFileChannel->setProperty("purgeCount", "100");

		//��־��ʽ;  
		AutoPtr<PatternFormatter> pPatternFormatter(new PatternFormatter);
		pPatternFormatter->setProperty("pattern", "%Y-%m-%d %H:%M:%S %s: %t");
		pPatternFormatter->setProperty("times", "local");

		AutoPtr<FormattingChannel> pFormattingChannelFile(new FormattingChannel(pPatternFormatter, pFileChannel));
		AutoPtr<FormattingChannel> pFormattingChannelConsole(new FormattingChannel(pPatternFormatter, pConsoleChannel));

		AutoPtr<SplitterChannel> pSplitterChannel(new SplitterChannel);
		pSplitterChannel->addChannel(pFormattingChannelFile);
		pSplitterChannel->addChannel(pFormattingChannelConsole);

		logger().setChannel(pSplitterChannel);

		logger().information("starting up");
	}

	void uninitialize()
	{
		logger().information("shutting down");
		ServerApplication::uninitialize();
	}

	void defineOptions(OptionSet& options)
	{
		ServerApplication::defineOptions(options);

		options.addOption(
			Option("help", "h", "display help information on command line arguments")
			.required(false)
			.repeatable(false)
			.callback(OptionCallback<QDRSServer>(this, &QDRSServer::handleHelp)));
	}

	void handleHelp(const std::string& name, const std::string& value)
	{
		_helpRequested = true;
		displayHelp();
		stopOptionsProcessing();
	}

	void displayHelp()
	{
		HelpFormatter helpFormatter(options());
		helpFormatter.setCommand(commandName());
		helpFormatter.setUsage("OPTIONS");
		helpFormatter.setHeader("A sample server application that demonstrates some of the features of the Util::ServerApplication class.");
		helpFormatter.format(std::cout);
	}

	int main(const ArgVec& args)
	{
		if (!_helpRequested)
		{
			//TaskManager tm;
			//tm.start(new TimeTask);
			//waitForTerminationRequest();
			//tm.cancelAll();
			//tm.joinAll();

			JobTaskMgr taskJob;

			Timer timer(1, 5000);
			timer.start(TimerCallback<JobTaskMgr>(taskJob, &JobTaskMgr::onMessage));
			waitForTerminationRequest();

			timer.stop();
		}
		return Application::EXIT_OK;
	}

private:
	bool _helpRequested;
};


POCO_SERVER_MAIN(QDRSServer)
