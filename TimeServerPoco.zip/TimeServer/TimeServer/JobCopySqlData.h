#ifndef ___JobCopy_SQL_DATE__H__
#define ___JobCopy_SQL_DATE__H__

#include "JobInterface.h"
#include <vector>
class WordItem
{
public:
	std::string id;
	std::string key;
	std::string value;
	std::string code;
	std::string type;
	std::string ip;
	std::string used_count;
	std::string date;
};



class JobCopySqlDate : public JobInterface
{
public:
	JobCopySqlDate();
	~JobCopySqlDate();

	int processJob(std::shared_ptr<sql::Connection> connection) override;

private:
	std::vector<WordItem> m_vecWordList;
};


#endif // !___JobCopy_SQL_DATE__H__
