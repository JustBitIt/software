#ifndef ___TIMER_CALL_BACK__H__
#define ___TIMER_CALL_BACK__H__

#include "PocoCommon.h"
#include <mysql_connection.h>
#include <mysql_driver.h>
#include <memory>
#include <functional>
#include "JobCopySqlData.h"

class JobTaskMgr
{
public:
	JobTaskMgr();
	~JobTaskMgr();
	bool init();
	
	void onMessage(Timer& timer);
	void setConnection(std::shared_ptr<sql::Connection> pConnection);
	std::shared_ptr<sql::Connection> getConnection();
private:
	void initJobList();
	void releaseJobList();
private:
	//Stopwatch _sw;
	//sql::Connection* m_pConnection;
	std::shared_ptr<sql::Connection> m_pConnection;
	//std::vector<std::function<void(sql::Connection*)>> m_JobList;
	std::vector<JobInterface*> m_vecJobList;
};

#endif // !___TIMER_CALL_BACK__H__
