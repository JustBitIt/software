#ifndef __JOB_INTERFACE__H____
#define __JOB_INTERFACE__H____
#include <mysql_connection.h>
#include <cppconn/prepared_statement.h>
#include <memory>

class JobInterface
{
public:

	virtual int processJob(std::shared_ptr<sql::Connection> connection) = 0;

};



#endif // !__JOB_INTERFACE__H____
