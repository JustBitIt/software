#include "JobTaskManager.h"


JobTaskMgr::JobTaskMgr()
{
	if (!init())
	{
		Application::instance().logger().information("JobTaskMgr init() faild! \n");
	}
}

JobTaskMgr::~JobTaskMgr()
{
	releaseJobList();
}

void JobTaskMgr::onMessage(Timer& timer)
{
	for  (auto job : m_vecJobList)
	{
		job->processJob(getConnection());
	}
}

bool JobTaskMgr::init()
{
	bool bRet = true;
	do 
	{
		//try
		//{
		//	std::string ip = Application::instance().config().getString("DateBase.host");
		//	std::string username = Application::instance().config().getString("DateBase.user");
		//	std::string password = Application::instance().config().getString("DateBase.password");
		//	std::string datebase_name = Application::instance().config().getString("DateBase.datebase_name");

		//	sql::Driver *pDriver = get_driver_instance();

		//	std::shared_ptr<sql::Connection> obj(pDriver->connect(ip.c_str(), username.c_str(), password.c_str()));

		//	setConnection(obj);

		//	getConnection()->setSchema(datebase_name.c_str());

		//}
		//catch (sql::SQLException& e) {
		//	std::cout << "# ERR: SQLException in " << __FILE__;
		//	std::cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << std::endl;
		//	std::cout << "# ERR: " << e.what();
		//	std::cout << " (MySQL error code: " << e.getErrorCode();
		//	std::cout << ", SQLState: " << e.getSQLState() << " )" << std::endl;
		//	bRet = false;
		//	break;
		//}

		initJobList();

	} while (0);


	return bRet;

}

void JobTaskMgr::setConnection(std::shared_ptr<sql::Connection> pConnection)
{
	m_pConnection = pConnection;
}

std::shared_ptr<sql::Connection> JobTaskMgr::getConnection()
{
	return m_pConnection;
}

void JobTaskMgr::initJobList()
{
	JobInterface* job = new JobCopySqlDate;
	m_vecJobList.push_back(job);
}

void JobTaskMgr::releaseJobList()
{
	for (auto itor = m_vecJobList.begin(); itor != m_vecJobList.end();)
	{
		delete *itor;
		itor++;
	}
	m_vecJobList.clear();
}


